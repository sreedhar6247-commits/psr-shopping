const products = [
  { id: "p1", name: "Elegant Silk Saree", category: "Sarees", price: 1299, emoji: "🥻" },
  { id: "p2", name: "Floral Kurti", category: "Kurtis", price: 699, emoji: "👚" },
  { id: "p3", name: "Party Wear Dress", category: "Dresses", price: 1199, emoji: "👗" },
  { id: "p4", name: "Women's Stylish Top", category: "Tops", price: 499, emoji: "👕" }
];

export default function Home() {
  return (
    <>
      <header className="header">
        <div className="logo">PSR Shopping</div>
        <div>🛒 Cart</div>
      </header>
      <main className="container">
        <section className="hero">
          <h1>Fashion for Every Occasion</h1>
          <p>Discover beautiful women's clothing at great prices.</p>
          <a className="button" href="#products">Shop Now</a>
        </section>

        <h2 id="products">Featured Products</h2>
        <div className="cards">
          {products.map((p) => (
            <article className="card" key={p.id}>
              <div className="emoji">{p.emoji}</div>
              <h3>{p.name}</h3>
              <p className="muted">{p.category}</p>
              <div className="price">₹{p.price}</div>
              <a className="button" href={`/products/${p.id}`}>View Product</a>
            </article>
          ))}
        </div>
      </main>
      <footer>© 2026 PSR Shopping</footer>
    </>
  );
}
