# PSR Shopping V3 Architecture

Customer browser -> Next.js frontend -> server/API -> PostgreSQL

Payment flow:
Customer -> server creates payment order -> payment gateway -> webhook -> server verifies payment -> order marked paid.

Admin:
Admin login -> server authentication -> protected admin API -> products/orders database.

Never put payment secrets, database passwords, or admin credentials in client-side code.
